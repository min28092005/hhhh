/*Cho hai dãy số nguyên 
 và 
 lần lượt có 
 và 
 phần tử. Hãy ghép chúng thành dãy 
 được bố trí theo thứ tự không giảm.

Dữ liệu vào:
Dòng đầu tiên chứa một số nguyên 
.
Dòng thứ hai chứa dãy 
 gồm 
 số nguyên.
Dòng thứ ba chứa một số nguyên 
.
Dòng thứ tư chứa dãy 
 gồm 
 số nguyên.
Dữ liệu ra:
Một dòng duy nhất là dãy 
 theo yêu cầu đề bài.
Input:
Copy
4
6 8 1 3
3
7 6 2
Output:
Copy
1 2 3 6 6 7 8
*/
#include <stdio.h>
#include <stdlib.h>

int cmp(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int main() {
    int n, m;
    scanf("%d", &n);
    int a[n];
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);

    scanf("%d", &m);
    int b[m];
    for (int i = 0; i < m; i++) scanf("%d", &b[i]);

    int c[n+m];
    for (int i = 0; i < n; i++) c[i] = a[i];
    for (int i = 0; i < m; i++) c[n+i] = b[i];

    qsort(c, n+m, sizeof(int), cmp);

    for (int i = 0; i < n+m; i++) {
        printf("%d", c[i]);
        if (i < n+m-1) printf(" ");
    }
    return 0;
}
