/*Tại một khu rừng nọ có 
 cái cây, các cây trong khu rừng đều được các nhà khoa học đặt tên. Cây thứ 
 có tên là một xâu ký tự chỉ gồm các chữ cái latỉnh in hoa (A đền Z) 
 và chiều cao là một số nguyên 
.

Yêu cầu:
Hãy sắp xếp danh sách các cây theo thứ tự chiều cao không giảm.
Nếu chiều cao bằng nhau thì sắp xếp theo tên không giảm.
Nếu tên lại giống nhau thì cây nào có chỉ số ban đầu nhỏ hơn sẽ đứng trước.
Dữ liệu vào:
Dòng đầu chứa số nguyên dương 
;
 dòng sau, dòng thứ 
 chứa xâu 
 có độ dài không quá 30 ký tự và chiều cao 
 được ghi cách nhau một dấu cách.
Dữ liệu ra:
Ghi ra trên một dòng 
 số nguyên là chỉ số của các cây sau khi đã sắp xếp.
Input:
Copy
5
H 2
U 2
D 1
C 3
E 5
Output:
Copy
3 1 2 4 5
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[31];
    int height;
    int index;
} Tree;

int compareTrees(const void *a, const void *b) {
    Tree *treeA = (Tree *)a;
    Tree *treeB = (Tree *)b;

    if (treeA->height != treeB->height) {
        return treeA->height - treeB->height;
    }

    int nameComparison = strcmp(treeA->name, treeB->name);
    if (nameComparison != 0) {
        return nameComparison;
    }

    return treeA->index - treeB->index;
}

int main() {
    int n;
    scanf("%d", &n);

    Tree trees[n];
    for (int i = 0; i < n; i++) {
        scanf("%s %d", trees[i].name, &trees[i].height);
        trees[i].index = i + 1; 
    }

    qsort(trees, n, sizeof(Tree), compareTrees);

    for (int i = 0; i < n; i++) {
        printf("%d ", trees[i].index);
    }
    printf("\n");

    return 0;
}
