/*Cho 
 số nguyên dương 
, và một số nguyên dương 
 Hãy tìm vị trí i sao cho 
, nếu có nhiều giá trị i thì trả về giá trị i lớn nhất, nếu không có giá trị i nào thoả mãn thì in ra 

INPUT:
Dòng thứ nhất chứa hai số n, k.
Dòng thứ hai chứa n số nguyên dương.
OUTPUT:
In ra vị trí 
 thoả mãn.
Input:
Copy
4 4
3 1 4 6
Output:
Copy
3
*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, k;
    
    if (scanf("%d %d", &n, &k) != 2) return 1;

    int a[n + 1]; 
    for (int i = 1; i <= n; i++) {
        if (scanf("%d", &a[i]) != 1) return 1;
    }

    int result_i = -1;
    for (int i = n; i >= 1; i--) {
        if (a[i] == k) {
            result_i = i;
            break;
        }
    }

    printf("%d\n", result_i);

    return 0;
}