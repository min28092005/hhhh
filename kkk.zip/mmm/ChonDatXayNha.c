/*Nate vừa mua được một mảnh đất ở thành phố ABC để xây nhà.

Khu đất của Nate có kích thước 
 mét vuông, với 
 là chiều dài, 
 là chiều rộng. Cậu muốn xây một ngôi nhà có dạng hình vuông có chiều dài là số nguyên dương có diện tích lớn nhất có thể và nằm hoàn toàn trong khu đất mà Nate đã mua. Tuy nhiên, để xây được một ngôi nhà an toàn, phần đất được chọn phải đạt được một số tiêu chí nhất định.

Nate đã tiến hành một cuộc khảo sát trên mảnh đất bằng cách chia mảnh đất thành các ô vuông nhỏ, mỗi ô có diện tích 
 
 và đưa ra số liệu về độ nguy hiểm của mỗi ô trên mảnh đất này. Độ nguy hiểm của ô ở hàng thứ 
, cột thứ 
 của mảnh đất là 
. Để một mảnh đất có kích thước 
 
 đạt tiêu chuẩn xây nhà, tổng độ nguy hiểm của tất cả các ô trong mảnh đất phải không vượt quá 
. Nói cách khác, một mảnh đất có kích thước 
 
 có góc trên bên trái là ô 
 và góc dưới bên phải là ô 
 (
) đạt tiêu chuẩn xây nhà khi và chỉ khi điều kiện sau thỏa mãn:


Mảnh đất của Nate mua rất lớn nên cậu nhờ bạn giúp. Hãy tìm chiều dài nhà 
 lớn nhất mà tồn tại một mảnh đất trong khu đất đã mua của Nate có thể xây nhà chiều dài 
. Nếu không tồn tại bất kỳ mảnh đất với bất kỳ kích thước nào có thể xây nhà, in ra 0.

Dữ liệu vào:
Dòng đầu tiên gồm hai số nguyên dương 
 (
; 
) lần lượt là chiều rộng, chiều dài của khu đất và độ nguy hiểm tối đa mà ngôi nhà có thể có.
 dòng tiếp theo, dòng thứ i gồm 
 số nguyên không âm 
 là độ an toàn của từng ô của khu đất (
).
Dữ liệu ra:
Một số nguyên 
 là đáp án của bài toán.
Input:
Copy
5 5 2
1 0 0 3 2
0 0 0 1 0
0 0 1 2 3
3 2 1 0 1
0 0 1 2 1
Output:
Copy
3*/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(){
    int n, m;
    long long S;
    if(scanf("%d %d %lld", &n, &m, &S)!=3) return 0;
    long long *a = malloc(sizeof(long long) * n * m);
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            scanf("%lld", &a[i*m + j]);
        }
    }

    int R = n, C = m;
    long long *ps = malloc(sizeof(long long) * (R+1) * (C+1));
    for(int i=0;i<=R;i++) for(int j=0;j<=C;j++) ps[i*(C+1)+j]=0;

    for(int i=1;i<=R;i++){
        for(int j=1;j<=C;j++){
            ps[i*(C+1)+j] = a[(i-1)*m + (j-1)]
                + ps[(i-1)*(C+1)+j] + ps[i*(C+1)+(j-1)] - ps[(i-1)*(C+1)+(j-1)];
        }
    }

    int lo = 1, hi = (R < C ? R : C), ans = 0;
    while(lo <= hi){
        int mid = (lo + hi) >> 1;
        int ok = 0;
        for(int i=1;i+mid-1<=R && !ok;i++){
            for(int j=1;j+mid-1<=C;j++){
                int r2 = i+mid-1, c2 = j+mid-1;
                long long sum = ps[r2*(C+1)+c2] - ps[(i-1)*(C+1)+c2] - ps[r2*(C+1)+(j-1)] + ps[(i-1)*(C+1)+(j-1)];
                if(sum <= S){ ok = 1; break; }
            }
        }
        if(ok){ ans = mid; lo = mid + 1; }
        else hi = mid - 1;
    }

    printf("%d\n", ans);

    free(a);
    free(ps);
    return 0;
}
