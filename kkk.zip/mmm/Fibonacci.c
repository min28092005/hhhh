/*Cho số nguyên dương 
. Hãy in ra số Fibonacci thứ 
. Định nghĩa số Fibonacci như sau

INPUT
Một số nguyên dương 
 (1 <= 
 <= 90)
OUTPUT
Giá trị số Fibonacci thứ 
INPUT
Copy
4
OUTPUT
Copy
3
*/
#include <stdio.h>

long long fibonacci(int n) {
    long long a = 0, b = 1, temp;
    for (int i = 2; i <= n; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }
    return n == 0 ? 0 : b;
}

int main() {
    int n;
    scanf("%d", &n);
    printf("%lld\n", fibonacci(n));
    return 0;
}
