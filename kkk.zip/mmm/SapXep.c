/*Cho một dãy số gồm 
 số nguyên dương 

Hãy in ra dãy sỗ trên sau khi được sắp xếp không giảm

Chú ý là không dùng thư viện để sắp xếp và tìm kiếm

Input :
Dòng đầu tiên gồm số nguyên 
Dòng hai là 
 số 
Output :
Trên một dòng gồm 
 số nguyên đã được sắp xếp
Ví dụ
Input

Copy
5
5 3 6 7 2
Output

Copy
2 3 5 6 7
*/
#include <stdio.h>

void merge(int a[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int L[n1], R[n2];
    for (int i = 0; i < n1; i++) L[i] = a[left + i];
    for (int i = 0; i < n2; i++) R[i] = a[mid + 1 + i];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j])
            a[k++] = L[i++];
        else
            a[k++] = R[j++];
    }

    while (i < n1) a[k++] = L[i++];
    while (j < n2) a[k++] = R[j++];
}

void mergeSort(int a[], int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;
        mergeSort(a, left, mid);
        mergeSort(a, mid + 1, right);
        merge(a, left, mid, right);
    }
}

int main() {
    int n;
    scanf("%d", &n);

    int a[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    mergeSort(a, 0, n - 1);

    for (int i = 0; i < n; i++) {
        printf("%d", a[i]);
        if (i != n - 1) printf(" ");
    }

    return 0;
}
