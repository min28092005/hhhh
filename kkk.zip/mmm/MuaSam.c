/*Kabasak1 đến cửa hàng để mua sắm. Có tổng cộng 
 mặt hàng trong cửa hàng và giá trị cửa các mặt hàng lần lượt là 
 đồng. Kasabak1 có tổng cộng 
 đồng, anh ấy hy vọng sẽ dùng số tiền đó để mua được nhiều vật phẩm nhất có thể.

Yêu cầu: Hãy tính số vật phẩm tối đa anh ấy có thể mua được.

Dữ liệu vào:
Dòng thứ nhất chứa hai số nguyên 
 và 
 
 - số mặt hàng và số tiền.
Dòng thứ hai chứa 
 số nguyên 
 
 - giá trị của các mặt hàng.
Dữ liệu ra:
Ghi ra một số nguyên là số mặt hàng tối đa có thể mua được.
Input:
Copy
5 9 
1 3 1 3 3
Output:
Copy
4
*/
#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int main() {
    int n, m;
    scanf("%d %d", &n, &m);

    int prices[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &prices[i]);
    }

    qsort(prices, n, sizeof(int), compare); 

    int count = 0;
    int total_cost = 0;
    for (int i = 0; i < n; i++) {
        if (total_cost + prices[i] <= m) {
            total_cost += prices[i];
            count++;
        } else {
            break;
        }
    }

    printf("%d\n", count);
    return 0;
}
