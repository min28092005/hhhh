/*Cho một danh sách liên kết đơn không có phần tử nào. Mỗi một nút trong danh sách liên kết đơn có chứa một số nguyên dương

Hãy thêm lần lượt n phần tử số nguyên dương vào cuối danh sách liên kết trên và in danh sách ra.

INPUT
Dòng 1 gồm một số nguyên dương n
Dòng 2 là n số nguyên dương a
OUTPUT
Gồm một dòng gồm n số nguyên dương theo thứ tự khi in danh sách liên kết từ đầu đến cuối. Các số cách nhau một dấu ký tự trắng
CONSTRAINTS
INPUT
Copy
4
2 1 5 9 
OUTPUT
Copy
2 1 5 9
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

void addAtTail(Node **head, int val) {
    Node* newNode = createNode(val);
    if(*head == NULL) { 
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while(temp->next != NULL) temp = temp->next;
    temp->next = newNode;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        printf("%d", temp->data);  
        if(temp->next) printf(" ");
        temp = temp->next; 
    }
    printf("\n");
}

int main() {
    int n, a;
    Node* head = NULL;  
    scanf("%d", &n); 

    for (int i = 0; i < n; i++) {
        scanf("%d", &a);
        addAtTail(&head, a); // thêm vào cuối
    }

    printList(head);

    return 0;
}
