/*Một sinh viên có các thống số sau:

Mã sinh viên (có 8 ký tự số)
Tên sinh viên (nhiều hơn 5 ký tự và không quá 30 ký tự bao gồm ký tự trắng)
Điểm GPA (là số thực nằm trong khoảng từ 0 đến 4)
Cho 
 thông tin sinh viên chưa được kiểm tra, bạn hãy kiểm tra xem có bao nhiêu sinh viên hợp lệ.

INPUT:
Một dòng duy nhất chứa số nguyên 
.
Tiếp theo là 
 dòng chứa thông tin của n sinh viên. Mỗi thông tin của sinh viên sẽ lưu trên một dòng
OUTPUT:
Một số nguyên duy nhất là số sinh viên có thông tin hợp lệ.
Input:
Copy
2
11223344
Nguyen Hoang Duong
2.1
223344a5
Bui Minh Duc
3.2
Output:
Copy
1
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    int n;
    scanf("%d", &n);
    getchar();

    int valid_count = 0;
    for (int i = 0; i < n; i++) {
        char code[20], name[100];
        float gpa;

        fgets(code, sizeof(code), stdin);
        code[strcspn(code, "\n")] = 0;

        fgets(name, sizeof(name), stdin);
        name[strcspn(name, "\n")] = 0;

        scanf("%f", &gpa);
        getchar();

        int code_valid = (strlen(code) == 8);
        for (int j = 0; j < 8 && code_valid; j++)
            if (!isdigit(code[j])) code_valid = 0;

        int name_valid = (strlen(name) >= 6 && strlen(name) <= 30);
        int gpa_valid = (gpa >= 0 && gpa <= 4);

        if (code_valid && name_valid && gpa_valid)
            valid_count++;
    }

    printf("%d\n", valid_count);
    return 0;
}
