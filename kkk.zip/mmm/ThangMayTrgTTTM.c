/*Một trung tâm thương mại có N tầng, được đánh số từ 1 đến N theo thứ tự từ dưới lên
trên. Tại mỗi tầng chỉ có duy nhất một nhân viên làm việc. Buổi sáng các nhân viên lái xe đến
tầng hầm (ở dưới tầng 1 một tầng). Trung tâm thương mại được trang bị một thang máy có thể
chứa số lượng người không giới hạn. Nhưng hôm nay người điều khiển thang máy khó tính chỉ
cho phép đưa tất cả nhân viên lên cùng một lần lên cùng một tầng nào đó.
Mỗi nhân viên có hai lựa chọn: Anh ta có thể đi cầu thang bộ, để đi bộ lên qua mỗi một
tầng mất A giây; hoặc anh ta có thể đi thang máy đến tầng mà các nhân viên lựa chọn, sau đó
ra khỏi thang máy và đi bộ lên hoặc xuống tầng của mình, đi bộ xuống qua mỗi tầng mất B
giây. Thang máy đi qua mỗi tầng mất C giây.
Bạn hãy xác định thời gian tối thiểu để tất cả các nhân viên đi đến vị trí làm việc của
mình sau khi các nhân viên đã thống nhất chọn được tầng mà thang máy đi lên và xác định
được lựa chọn của từng người (đi bộ hoặc đi thang máy sau đó đi bộ)
INPUT
Dòng đầu tiên chứa số nguyên dương N là số tầng của trung tâm thương mại, tiếp theo 3
dòng chứa các số nguyên dương A, B, C – tương ứng là thời gian đi bộ lên một tầng, đi bộ
xuống một tầng và thời gian thang máy đi lên qua một tầng. ,
.
OUTPUT
Một số nguyên dương thể hiện thời gian tối thiểu để tất cả các nhân viên đạt đến tầng của
mình.
Ví dụ:
Đầu vào Đầu ra Giải thích
6
20
10
5
45 Tòa nhà có 6 tầng, đi bộ lên 1 tầng mất 20 giây, đi bộ xuống 1 tầng mất
10 giây, thang máy đi lên 1 tầng mất 5 giây. Phương án nhanh nhất là
thang máy đi đến tầng 5 mất 25 giây, nhân viên ở tầng 6 đi bộ lên mất
thêm 20 giây, tổng cộng là 45 giây. Nhân viên ở tầng 4 đi bộ xuống
mất thêm 10 giây, tổng cộng là 35 giây. Nhân viên tầng 3 cũng đi bộ
xuống mất tổng cộng 45 giây. Nhân viên tầng 1, 2 đi bộ từ tầng hầm
lên mất lần lượt 20 và 40 giây.
*/
#include <stdio.h>
#include <stdlib.h>

long long N_max, A, B, C;

long long min_time_i(long long i, long long X) {
    long long time_walk = i * A;
    long long time_elevator = X * C;
    long long time_walk_after_elevator;

    if (i > X) {
        time_walk_after_elevator = (i - X) * A;
    } else {
        time_walk_after_elevator = (X - i) * B;
    }

    long long time_combined = time_elevator + time_walk_after_elevator;

    return (time_walk < time_combined) ? time_walk : time_combined;
}

long long total_time(long long X) {
    long long current_max_time = 0;
    
    for (long long i = 1; i <= N_max; i++) {
        long long t = min_time_i(i, X);
        if (t > current_max_time) {
            current_max_time = t;
        }
    }
    return current_max_time;
}

int main() {
    if (scanf("%lld", &N_max) != 1) return 1;
    if (scanf("%lld", &A) != 1) return 1;
    if (scanf("%lld", &B) != 1) return 1;
    if (scanf("%lld", &C) != 1) return 1;

    
    long long L = 1;
    long long R = N_max;

    if (R < L) {
        printf("%lld\n", N_max * A);
        return 0;
    }
    
    long long min_total_time = total_time(1); 
    
    while (R - L >= 3) {
        long long m1 = L + (R - L) / 3;
        long long m2 = R - (R - L) / 3;
        
        long long t1 = total_time(m1); 
        long long t2 = total_time(m2);

        if (t1 < t2) {
            R = m2 - 1; 
        } else {
            L = m1 + 1; 
        }
    }
   
    for (long long X = L; X <= R; X++) {
        long long current_time = total_time(X);
        if (current_time < min_total_time) {
            min_total_time = current_time;
        }
    }

    printf("%lld\n", min_total_time);

    return 0;
}