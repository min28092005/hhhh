/*Nhập vào một só nguyên n

Kiểm tra n có phải là số hoàn hảo không. Nếu có in "YES", không in "NO"

Só hoàn hảo là số có tổng các ước của nó bằng chính nó ( không kể nó )

INPUT
Nhập n 

OUTPUT
YES/NO

INPUT
Copy
6
OUTPUT
Copy
YES
*/
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int sum = 0;
    for (int i = 1; i < n; i++) {
        if (n % i == 0) sum += i;
    }

    if (sum == n)
        printf("YES\n");
    else
        printf("NO\n");

    return 0;
}
