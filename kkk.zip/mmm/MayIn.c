/*Datto có một file Word chứa tài liệu mật môn tin học, anh ấy muốn in nó ra thành 
 quyển đem đi bán. Tiệm in gần nhà Datto có 
 máy in đánh số từ 1 đến n, máy thứ i mất 
 thời gian để in ra 1 quyền tài liệu. Biết mỗi máy có thể hoạt động đồng thời và bạn có thể tự do quyết định lịch trình của chúng.

Thời gian ngắn nhất để in ra 
 cuốn tài liệu là bao nhiêu ?

Dữ liệu vào:
Dòng đầu tiên có hai số nguyên 
 
 và 
 
: số lượng máy móc và sản phẩm.
Dòng tiếp theo ghi 
 số nguyên 
 
 : thời gian mỗi máy cần để tạo ra 1 quyển tài liệu
Dữ liệu ra:
In một số nguyên: thời gian tối thiểu cần thiết để tạo ra 
 sản phẩm.
Input:
Copy
3 7
3 2 5
Output:
Copy
8
*/
#include <stdio.h>
#include <limits.h>

int main(){
    int n;
    long long m;
    if(scanf("%d %lld", &n, &m)!=2) return 0;
    long long t[n];
    for(int i=0;i<n;i++) scanf("%lld",&t[i]);

    long long lo = 0, hi = (long long)1e18;
    while(lo < hi){
        long long mid = lo + (hi - lo) / 2;
        __int128 produced = 0;
        for(int i=0;i<n;i++){
            produced += mid / t[i];
            if(produced >= m) break;
        }
        if(produced >= m) hi = mid;
        else lo = mid + 1;
    }

    printf("%lld\n", lo);
    return 0;
}
