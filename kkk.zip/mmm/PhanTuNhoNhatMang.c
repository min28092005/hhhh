/*Cho dãy số nguyên có 
 phần tử. Hãy in ra phần tử nhỏ nhất của mảng.

Dữ liệu đầu vào (Input)
Dòng đầu tiên ghi số 
 (
).
Dòng tiếp theo ghi 
 phần tử (
), các phần tử cách nhau bởi dấu cách.
Dữ liệu đầu ra (Output)
In ra một số duy nhất là phần tử nhỏ nhất của dãy.
Ví dụ
Input
Copy
5
1 4 0 2 -3
Output
Copy
-3
*/
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int x, min;
    scanf("%d", &x);
    min = x;

    for (int i = 1; i < n; i++) {
        scanf("%d", &x);
        if (x < min) min = x;
    }

    printf("%d\n", min);
    return 0;
}
