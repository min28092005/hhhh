/*Cho một danh sách liên kết đơn không có phần tử nào. Mỗi một nút trong danh sách liên kết đơn có chứa một số nguyên dương

Hãy thêm vào giữa danh sách trên n phần tử số nguyên dương và in danh sách ra

INPUT
Dòng 1 gồm một số nguyên dương n
N dòng tiếp theo, mỗi dòng có hai số nguyên a, b tương ứng với thêm phần tử có giá trị là a vào sau phần tử có giá trị b trong danh sách. Nếu trong danh sách không chứa phần từ b thì phần tử a vào đầu danh sách.
OUTPUT
Gồm một dòng gồm n số nguyên dương theo thứ tự khi in danh sách liên kết từ đầu đến cuối. Các số cách nhau một dấu ký tự trắng
CONSTRAINTS
INPUT
Copy
4
2 5
6 2
7 3
9 7 
OUTPUT
Copy
7 9 2 6
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int val) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = val;
    node->next = NULL;
    return node;
}

void insertAfter(Node **head, int a, int b) {
    Node* newNode = createNode(a);
    Node* cur = *head;

    while(cur) {
        if(cur->data == b) { // tìm thấy b
            newNode->next = cur->next;
            cur->next = newNode;
            return;
        }
        cur = cur->next;
    }
    // nếu không tìm thấy b → thêm vào đầu
    newNode->next = *head;
    *head = newNode;
}

void printList(Node* head) {
    Node* cur = head;
    while(cur) {
        printf("%d", cur->data);
        if(cur->next) printf(" ");
        cur = cur->next;
    }
    printf("\n");
}

int main() {
    int n, a, b;
    Node* head = NULL;
    scanf("%d", &n);

    for(int i = 0; i < n; i++) {
        scanf("%d %d", &a, &b);
        insertAfter(&head, a, b);
    }

    printList(head);
    return 0;
}
