/*Sau khi kỳ thi cuối kỳ kết thúc, các sinh viên đang háo hức chờ đợi kết quả. Trường đại học đã thông báo rằng điểm thi sẽ được công bố trên hệ thống quản lý sinh viên trực tuyến. Mark là một lập trình viên xuất sắc được giao nhiệm vụ viết code để sinh viên có thể tra cứu dễ dàng.

Nhưng Mark đang bận ôn thi môn CTDL&TT nên bạn hãy làm hộ Mark

Chú ý là không dùng thư viện để sắp xếp và tìm kiếm

INPUT:
Dòng một là số nguyên dương n và m, trong n là số sinh viên dự thi và m là số lượt sinh viên tra cứu điểm thi
N dòng tiếp theo thông số của một sinh viên gồm có 1 số nguyên dương 6 chữ số là mã sinh viên và một số nguyên dương u là điểm thi của sinh viên. Mã sinh viên của hai sinh viên luôn khác nhau
Một dòng cuối cùng là m số mã sinh viên a1, a2, .. am
OUTPUT:
Là một dòng duy nhật chứa m số nguyên b1, b2, .. bm. Trong đó bi là điểm của sinh viên có mã ai. Nếu không tồn tại mã sinh viên bi thì trả về -1
CONSTRAINTS:
Input
Copy
5 7
111111 23
222222 87
333333 56
444444 77
555555 81
111111 333333 555555 111111 444444 111111 555555
Output
Copy
23 56 81 23 77 23 81
*/
#include <stdio.h>

typedef struct {
    int id;
    int score;
} Student;

void merge(Student a[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Student L[n1], R[n2];
    for (int i = 0; i < n1; i++) L[i] = a[left + i];
    for (int i = 0; i < n2; i++) R[i] = a[mid + 1 + i];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i].id < R[j].id)
            a[k++] = L[i++];
        else
            a[k++] = R[j++];
    }
    while (i < n1) a[k++] = L[i++];
    while (j < n2) a[k++] = R[j++];
}

void mergeSort(Student a[], int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;
        mergeSort(a, left, mid);
        mergeSort(a, mid + 1, right);
        merge(a, left, mid, right);
    }
}

int binarySearch(Student a[], int n, int x) {
    int l = 0, r = n - 1;
    while (l <= r) {
        int mid = (l + r) / 2;
        if (a[mid].id == x) return a[mid].score;
        else if (a[mid].id < x) l = mid + 1;
        else r = mid - 1;
    }
    return -1;
}

int main() {
    int n, m;
    scanf("%d %d", &n, &m);

    Student a[n];
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &a[i].id, &a[i].score);
    }

    mergeSort(a, 0, n - 1);

    for (int i = 0; i < m; i++) {
        int x;
        scanf("%d", &x);
        int result = binarySearch(a, n, x);
        printf("%d", result);
        if (i != m - 1) printf(" ");
    }

    return 0;
}
