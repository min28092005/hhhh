/*Một xâu gọi là xâu nhị phân nếu chỉ chứa hai ký tự “0” hoặc “1”. Xâu v gọi là xâu con
của w nếu xâu v có độ dài khác 0 và gồm các ký tự liên tiếp trong xâu w. Ví dụ: xâu
“010” có các xâu con là “0”, “1”, “0”, “01”, “10”, “010”.
Yêu cầu: Cho trước một giá trị K, hãy đếm xem có bao nhiêu xâu con chứa đúng K ký tự
“1”.
INPUT
• Dòng 1 chứa một số nguyên K (0 ≤ K ≤ 106
);
• Dòng 2 chứa một xâu nhị phân có độ dài không quá 106
.
OUTPUT
Một số nguyên duy nhất là kết quả tìm được.
Ví dụ:
INPUT OUTPUT Giải thích
2
01010
4 Có 4 xâu chứa 2 ký tự “1” là:
“101”, “0101”, “1010”,
“01010”.
2
1111
3
Ràng buộc:
• Có 60% test ứng 60% số điểm của bài với K ≤ 100 và độ dài của xâu không quá
100;
• Có 20% test ứng 20% số điểm của bài với K ≤ 254 và độ dài của xâu không quá
254;
• Có 20% test khác ứng với 20% số điểm còn lại của bài với K ≤ 106
và độ dài của
xâu không quá 106
*/
#include <stdio.h>
#include <string.h>

long long cnt[1000005];

int main() {
    int K;
    scanf("%d", &K);

    static char s[1000005];
    scanf("%s", s);

    int n = strlen(s);

    if (K == 0) {
        long long ans = 0;
        long long run = 0;
        for (int i = 0; i < n; i++) {
            if (s[i] == '0') run++;
            else run = 0;
            ans += run;
        }
        printf("%lld", ans);
        return 0;
    }

    long long ans = 0;
    long long pref = 0;

    cnt[0] = 1;

    for (int i = 0; i < n; i++) {
        if (s[i] == '1') pref++;

        if (pref >= K)
            ans += cnt[pref - K];

        cnt[pref]++;
    }

    printf("%lld", ans);
    return 0;
}
