/*Cho một queue lưu trữ tối đa 1000 phần tử, mỗi phần tử là các số nguyên, ban đầu queue rỗng có hai loại hành động được ký hiệu như sau:

1 : là lấy một ký tự ra khỏi queue
2 u : là thêm một phần tử u vào trong queue
Yêu cầu là in ra toàn bộ queue sau khi đã thực hiện các hành động

INPUT
Dòng đầu tiên gồm một số nguyên dương n tương ứng với có n hành động
Tiếp theo có n dòng mỗi dòng lưu thông tin của một hành động
OUTPUT
Là kết quả in ra lần lượt lấy phần tử ra trong queue đến khi queue rỗng
CONSTRAINTS
INPUT
Copy
6
1
2 8
2 9
1
2 4
2 6
OUTPUT
Copy
9 4 6
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    long long data;
    struct Node *next;
} Node;

typedef struct Queue {
    Node *front;
    Node *rear;
} Queue;

Queue* createQueue() {
    Queue *q = (Queue*)malloc(sizeof(Queue));
    q->front = q->rear = NULL;
    return q;
}

int is_empty(Queue *q) {
    return q->front == NULL;
}

void enqueue(Queue *q, long long u) {
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->data = u;
    temp->next = NULL;

  
    if (q->rear == NULL) {
        q->front = q->rear = temp;
        return;
    }

    q->rear->next = temp;
    q->rear = temp;
}

void dequeue(Queue *q) {
    if (is_empty(q)) return;

 
    Node *temp = q->front;
    q->front = q->front->next;

    if (q->front == NULL) {
        q->rear = NULL;
    }

    free(temp);
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 1;

    Queue *q = createQueue();

    for (int i = 0; i < n; i++) {
        int type;
        if (scanf("%d", &type) != 1) break;

        if (type == 1) {
            dequeue(q);
        } else if (type == 2) {
            long long u;
            if (scanf("%lld", &u) != 1) break;
            enqueue(q, u);
        }
    }

    int is_first = 1;
    while (!is_empty(q)) {
        if (!is_first) {
            printf(" ");
        }
        printf("%lld", q->front->data);
        dequeue(q); 
        is_first = 0;
    }
    printf("\n");
    free(q); 

    return 0;
}