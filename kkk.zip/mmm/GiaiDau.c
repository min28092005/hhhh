/*Một giải đấu nằm trong hệ thống giải Olympic có N đội tham gia, N là một số lũy thừa của 2,
N = 2k
(theo thể thức các giải Olympic chỉ đội chiến thắng ở các cặp đấu đi tiếp vào vòng sau,
không có trận hòa).
Các đội được đánh số hiệu từ 1 tới N. Ở vòng đầu tiên, các cặp đấu lần lượt là 1 với 2, 3 với 4,
v.v., như vậy có tất cả N/2 trận đấu. Tương tự ở vòng thứ 2 có N/4 trận đấu, các đội thắng của
trận thứ 1 và thứ 2 gặp nhau, thứ 3 và thứ 4 gặp nhau, v.v. Cứ như vậy đến vòng cuối cùng.
Giả sử bạn có kết quả của tất cả các trận đấu theo thứ tự, cần chỉ ra đội nào là đội vô địch.
INPUT
Dòng thứ nhất chứa 1 số N thể hiện số đội tham dự giải, N là lũy thừa của 2 và nhận giá
trị từ 2
0 = 1 đến 216 = 65536. Tiếp theo là N-1 dòng thể hiện kết quả các trận đấu trong giải,
lưu ý N/2 dòng đầu tiên thể hiện kết quả vòng 1, tiếp theo N/4 dòng thể hiện kết quả vòng 2,
v.v. Kết quả mỗi trận đấu nhận giá trị 1 hoặc 2, trong đó 1 thể hiện rằng đội thứ nhất của cặp
đấu (đội có số hiệu nhỏ hơn) chiến thắng, 2 có nghĩa là đội có số hiệu lớn hơn chiến thắng.
OUTPUT
Một số thể hiện số hiệu của đội vô địch giải đấu.
Ví dụ:
INPUT OUTPUT Giải thích
8
1
2
2
1
2
1
1
4 Các cặp đấu ở vòng 1 là (1,2); (3, 4); (5, 6); (7,
8). Các đội chiến thắng vòng 1 là 1, 4, 6, 7. Ở
vòng 2 có 2 cặp đấu là (1, 4); (6, 7), các đội chiến
thắng là 4, 6. Trận chung kết đội số 4 là đội chiến
thắng giành chức vô địch.
*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int N;
    scanf("%d", &N);

    int *teams = (int*)malloc(N * sizeof(int));
    for(int i=0; i<N; i++) teams[i] = i+1; // đội 1..N

    int remaining = N;
    int *next_round = (int*)malloc(N * sizeof(int));

    int res;
    while(remaining > 1) {
        for(int i=0; i<remaining/2; i++) {
            scanf("%d", &res);
            if(res == 1) next_round[i] = teams[2*i];      // đội thứ nhất thắng
            else       next_round[i] = teams[2*i+1];    // đội thứ hai thắng
        }
        remaining /= 2;
        for(int i=0; i<remaining; i++) teams[i] = next_round[i]; // chuyển sang vòng tiếp theo
    }

    printf("%d\n", teams[0]);

    free(teams);
    free(next_round);
    return 0;
}
