/*Giả sử bạn là một học sinh tại trường đại học Phenikaa . Bạn được cho n chiếc hộp
khác nhau . Mỗi chiếc hộp được đánh dấu từ 1 tới 𝑛 . Trong chiếc hộp thứ 𝑖 chứa 𝐴𝑖 viên bi .
Thầy giáo đã đố bạn 𝑞 câu hỏi có dạng :“ Trong các hộp được đánh số từ 𝑙 tới 𝑟 có bao nhiêu
hộp chứa x viên bi ” . Là một sinh viên chăm chỉ , hãy trả lời hết những câu hỏi của thầy nhé!
Input
• Dòng đầu tiên gồm 2 số nguyên 𝑛, 𝑞.
• Dòng tiếp theo gồm 𝑛 số nguyên 𝐴𝑖 cách nhau bởi dấu cách.
• 𝑞 dòng tiếp theo mỗi dòng gồm 3 số nguyên 𝑙, 𝑟, 𝑘 cách nhau bởi dấu cách.
Output
• In ra 𝑞 dòng, dòng thứ 𝑖 là kết quả của truy vấn 𝑖.
Điều kiện
• 1 ≤ 𝑛, 𝑞, 𝑘, 𝐴𝑖 ≤ 105
• 1 ≤ 𝑙 ≤ 𝑟 ≤ 𝑛
Đầu vào Đầu ra
7 3
1 2 1 4 2 4 2
1 4 1
2 7 2
3 5 4
2
3
1
*/
#include <stdio.h>
#include <stdlib.h>

#define MAX_VAL 100005

typedef struct {
    int *pos;   // mảng lưu vị trí xuất hiện của giá trị
    int cnt;    // số lượng vị trí
    int cap;    // dung lượng hiện tại
} List;

List lists[MAX_VAL];

int lower_bound(int *arr, int n, int x) {
    int l = 0, r = n; // arr[0..n-1]
    while (l < r) {
        int mid = (l + r) / 2;
        if (arr[mid] >= x) r = mid;
        else l = mid + 1;
    }
    return l;
}

int upper_bound(int *arr, int n, int x) {
    int l = 0, r = n;
    while (l < r) {
        int mid = (l + r) / 2;
        if (arr[mid] > x) r = mid;
        else l = mid + 1;
    }
    return l;
}

int main() {
    int n, q;
    scanf("%d %d", &n, &q);

    for (int i = 0; i < n; i++) {
        int Ai;
        scanf("%d", &Ai);
        if (lists[Ai].pos == NULL) {
            lists[Ai].cap = 1;
            lists[Ai].cnt = 0;
            lists[Ai].pos = (int*)malloc(sizeof(int) * lists[Ai].cap);
        }
        if (lists[Ai].cnt == lists[Ai].cap) {
            lists[Ai].cap *= 2;
            lists[Ai].pos = (int*)realloc(lists[Ai].pos, sizeof(int) * lists[Ai].cap);
        }
        lists[Ai].pos[lists[Ai].cnt++] = i + 1; // lưu vị trí 1-based
    }

    for (int i = 0; i < q; i++) {
        int l, r, k;
        scanf("%d %d %d", &l, &r, &k);
        if (lists[k].cnt == 0) {
            printf("0\n");
            continue;
        }
        int lb = lower_bound(lists[k].pos, lists[k].cnt, l);
        int ub = upper_bound(lists[k].pos, lists[k].cnt, r);
        printf("%d\n", ub - lb);
    }

    // Giải phóng bộ nhớ
    for (int i = 0; i < MAX_VAL; i++) {
        if (lists[i].pos != NULL) free(lists[i].pos);
    }

    return 0;
}
