/*Trong một trường học có 𝑛 sinh viên, sinh viên thứ i sẽ có mã 
 là một số nguyên và có điếm số 
 cũng là một số nguyên. Nhà trường có 3 suất học bổng toàn phần bao gồm cả học phí, chí phí sinh hoạt trị giá 500 triệu một năm.

Bạn hãy giúp nhà trường tìm ra 3 bạn có điểm cao nhất để nhà trường trao học bổng

INPUT
Dòng một là số nguyên dương 
 dòng tiếp theo mỗi dòng sẽ gồm hai chỉ số 
 và 
 của sinh viên thứ 
OUTPUT
Trên một dòng gồm 3 mã sinh viên theo thứ tự như sau: sinh viên có điểm cao nhất, sinh viên có điểm cao thứ hai, sinh viên có điểm cao thứ ba
CONSTRAINTS
INPUT
Copy
5
11 5
22 3
55 6
88 7
44 2

OUTPUT
Copy
88 55 11
*/
#include <stdio.h>

typedef struct {
    int id;
    int score;
} Student;

int main() {
    int n;
    scanf("%d", &n);
    Student s[n];

    for(int i=0; i<n; i++)
        scanf("%d %d", &s[i].id, &s[i].score);

    for(int i=0; i<n-1; i++){
        for(int j=i+1; j<n; j++){
            if(s[j].score > s[i].score){
                Student tmp = s[i];
                s[i] = s[j];
                s[j] = tmp;
            }
        }
    }

    printf("%d %d %d\n", s[0].id, s[1].id, s[2].id);

    return 0;
}
