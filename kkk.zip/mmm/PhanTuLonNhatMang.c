/*Cho dãy số nguyên có 
 phần tử. Hãy in ra phần tử lớn nhất của mảng.

Dữ liệu đầu vào (Input)
Dòng đầu tiên ghi số 
 (
).
Dòng tiếp theo ghi 
 phần tử (
), các phần tử cách nhau bởi dấu cách.
Dữ liệu đầu ra (Output)
In ra một số duy nhất là phần tử lớn nhất của dãy.
Ví dụ
Input
Copy
5
1 4 0 2 -3
Output
Copy
4
*/
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int x, max;
    scanf("%d", &x);
    max = x;

    for (int i = 1; i < n; i++) {
        scanf("%d", &x);
        if (x > max) max = x;
    }

    printf("%d\n", max);
    return 0;
}
