/*Cho một danh sách liên kết vòng không có có phần tử. Mỗi một nút trong danh sách liên kết vòng có chứa một số nguyên dương

Hãy thêm vào cuối danh sách trên n phần tử số nguyên dương và in danh sách ra

INPUT
Dòng đầu tiên gồm một số nguyên dương n
Dòng thứ hai là n số nguyên dương a
OUTPUT
Gồm một dòng gồm n số nguyên dương theo thứ tự khi in danh sách từ đầu đến cuối.
CONSTRAINTS
INPUT
Copy
4 2
2 6 7 9 
OUTPUT
Copy
2 6 7 9
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int val) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = val;
    node->next = NULL;
    return node;
}

void addAtTail(Node** head, int val) {
    Node* newNode = createNode(val);
    if(*head == NULL) {
        newNode->next = newNode;
        *head = newNode;
    } else {
        Node* tail = *head;
        while(tail->next != *head) tail = tail->next;
        tail->next = newNode;
        newNode->next = *head;
    }
}

void printList(Node* head) {
    if(!head) return;
    Node* cur = head;
    do {
        printf("%d", cur->data);
        cur = cur->next;
        if(cur != head) printf(" ");
    } while(cur != head);
    printf("\n");
}

int main() {
    int n, val;
    Node* head = NULL;
    scanf("%d", &n);
    for(int i=0;i<n;i++){
        scanf("%d",&val);
        addAtTail(&head,val);
    }
    printList(head);
    return 0;
}
