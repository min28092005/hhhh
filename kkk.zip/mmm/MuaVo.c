/*Một ngày nọ, Tí đến nhà sách trung tâm để mua sắm sách vở và các dụng cụ học tập cần thiết, chuẩn bị cho năm học mới. Tí cần mua thêm 
 quyển vở và 
 cây bút. Tại nhà sách trung tâm, giá của mỗi quyển vở là 
 và giá của mỗi cây bút là 
 . Hãy giúp Tí xác định số tiền ít nhất cần mang theo nhé.

Dữ liệu vào:
Gồm bốn số nguyên 
 - số quyển vở Tí cần mua thêm, số cây bút Tí cần mua thêm, giá tiền của mỗi quyển vở và giá tiền của mỗi cây bút.
Dữ liệu ra:
In ra một số nguyên duy nhất là số tiền ít nhất Tí cần mang theo.
Input:
Copy
2 3 4 1
Output:
Copy
11
Input:
Copy
1 0 3 5
Output:
Copy
3*/
#include <stdio.h>

int main() {
    int a, b, x, y;
    scanf("%d %d %d %d", &a, &b, &x, &y);
     int money = a*x + b*y ;
    printf("%d\n", money);

    return 0;
}