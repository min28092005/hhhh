/*Cho một danh sách liên kết đơn không có phần tử nào. Mỗi một nút trong danh sách liên kết đơn có chứa một số nguyên dương

Hãy thêm vào đầu danh sách trên n phần tử số nguyên dương, rồi xoá ở đầu danh sách đi m phần tử

INPUT
Dòng đầu tiên gồm hai số nguyên dương n, m
Dòng thứ hai là n số nguyên dương a
OUTPUT
Gồm một dòng gồm (n – m) số nguyên dương theo thứ tự khi in danh sách liên kết từ đầu đến cuối.
CONSTRAINTS
INPUT
Copy
4 2
2 6 7 9 
OUTPUT
Copy
6 2
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int val) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = val;
    node->next = NULL;
    return node;
}

void addAtHead(Node** head, int val) {
    Node* newNode = createNode(val);
    newNode->next = *head;
    *head = newNode;
}

void deleteHead(Node** head) {
    if(*head == NULL) return;
    Node* temp = *head;
    *head = (*head)->next;
    free(temp);
}

void printList(Node* head) {
    Node* cur = head;
    while(cur) {
        printf("%d", cur->data);
        if(cur->next) printf(" ");
        cur = cur->next;
    }
    printf("\n");
}

int main() {
    int n, m, val;
    Node* head = NULL;
    scanf("%d %d", &n, &m);
    for(int i=0;i<n;i++){
        scanf("%d",&val);
        addAtHead(&head,val);
    }

    for(int i=0;i<m;i++){
        deleteHead(&head);
    }

    printList(head);
    return 0;
}
