/*Cho 
 số nguyên dương 
 và số nguyên dương 
, hãy lần lượt thêm n số trên vào cây BST (ban đầu cây BST rỗng), nếu có số giống nhau trong n số thì chỉ thêm một số vào cây BST.

Sau đó xóa đi phần tử có giá trị k trên cây BST. Nếu gặp nút cần xoá có 2 con thì chọn nút trái nhất bên phải để thay thế

INPUT
Dòng một gồm hai số nguyên dương n và k.
Dòng hai là n số trong mảng một chiều.
OUTPUT
Là kết quả in cây BST sau khi xoá khi duyệt tiền thứ tự
Constraints
；
Input:
Copy
6 19
37 25 38 11 16 19
Output:
Copy
37 25 11 16 38
Input:
Copy
3 3
3 3 4
Output:
Copy
4
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* insert(Node* root, int data) {
    if (root == NULL) return createNode(data);
    if (data < root->data) root->left = insert(root->left, data);
    else if (data > root->data) root->right = insert(root->right, data);
    return root;
}

Node* findMin(Node* node) {
    Node* current = node;
    while (current->left != NULL) current = current->left;
    return current;
}

Node* deleteNode(Node* root, int k) {
    if (root == NULL) return root;
    if (k < root->data) root->left = deleteNode(root->left, k);
    else if (k > root->data) root->right = deleteNode(root->right, k);
    else {
        if (root->left == NULL) {
            Node* temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            Node* temp = root->left;
            free(root);
            return temp;
        }
        Node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

void preorderTraversal(Node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);
    }
}

int main() {
    int n, k, num;
    Node* root = NULL;
    scanf("%d %d", &n, &k);
    for (int i = 0; i < n; i++) {
        scanf("%d", &num);
        root = insert(root, num);
    }
    root = deleteNode(root, k);
    preorderTraversal(root);
    return 0;
}
