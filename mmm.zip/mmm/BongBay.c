/*Bạn Việt cầm trên tay 
 quả bóng bay, nhưng bạn Mạnh lại chọc nổ mất 
 quả. Bạn hãy giúp Việt đếm xem còn bao nhiêu quả bóng nhé!

Dữ liệu vào:
Một dòng gồm hai số nguyên dương 
.
Dữ liệu ra:
In ra một số nguyên duy nhất là kết quả bài toán.
Input:
Copy
5 2
Output:
Copy
3*/
#include <stdio.h>

int main() {
    int n, m;
    scanf("%d %d", &n, &m);
    printf("%d\n", n - m);
    return 0;
}