/*Cho một danh sách liên kết đơn không có phần tử nào. Mỗi một nút trong danh sách liên kết đơn có chứa một số nguyên dương

Hãy thêm vào đầu danh sách trên n phần tử số nguyên dương và in danh sách ra.

INPUT
Dòng 1 gồm một số nguyên dương n
Dòng 2 là n số nguyên dương a
OUTPUT
Gồm một dòng gồm n số nguyên dương theo thứ tự khi in danh sách liên kết từ đầu đến cuối. Các số cách nhau một dấu ký tự trắng
CONSTRAINTS
INPUT
Copy
4
2 6 7 9 
OUTPUT
Copy
9 7 6 2
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

void addAtHead(Node **head, int val) {
    Node* newNode = createNode(val);
    newNode->next = *head; 
    *head = newNode;        
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);  
        temp = temp->next; 
    }
}

int main() {
    int n, a;
    Node* head = NULL;  
    scanf("%d", &n); 

    for (int i = 0; i < n; i++) {
        scanf("%d", &a);
        addAtHead(&head, a);
    }

    printList(head);
    printf("\n");

    return 0;
}
