/*Cho 
 số nguyên dương 
 Hãy thêm n số trên vào một cây BST (ban đầu cây rỗng) Nếu có số giống nhau trong n số thì chỉ thêm một số vào cây BST

INPUT
Dòng một là số n nguyên dương
Dòng hai là n số nguyên dương
OUTPUT
Là dãy số in ra khi duyệt tiền thứ tự cây BST
CONSTRAINTS
input
Copy
4
4 3 1 9
output
Copy
4 3 1 9
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* insert(Node* root, int data) {
    if (root == NULL) return createNode(data);
    if (data < root->data) root->left = insert(root->left, data);
    else if (data > root->data) root->right = insert(root->right, data);
    return root;
}

void preorderTraversal(Node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);
    }
}

int main() {
    int n, num;
    Node* root = NULL;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &num);
        root = insert(root, num);
    }
    preorderTraversal(root);
    return 0;
}
