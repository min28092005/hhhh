/*Cho hai số nguyên dương 
 và 
. Tính diện tích, chu vi của hình chữ nhật có độ dài các cạnh lần lượt là 
 và 
.

Dữ liệu vào:
Một dòng duy nhất chứa hai số nguyên dương 
 được ghi cách nhau bới một khoảng trắng.
Dữ liệu ra:
Ghi ra trên một dòng hai số nguyên là chu vi và diện tích của hình chữ nhật tương ứng, hai số được ghi cách nhau bởi một khoảng trắng.
Input:
Copy
2 3
Output:
Copy
10 6*/
#include <stdio.h>

int main() {
    int a, b;
    long long chuvi, dientich;

    scanf("%d %d", &a, &b);

    chuvi = 2LL * (a + b);
    dientich = (long long)a * b;

    printf("%lld %lld\n", chuvi, dientich);

    return 0;
}
