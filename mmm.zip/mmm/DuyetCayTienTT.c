/*
Cho một cây nhị phân đang được lưu ở mảng một chiều (bắt đầu từ 0) có 
 phần tử Hãy in ra giá trị của node khi duyệt theo tiền tứ thự của cây đó

INPUT
Dòng đầu tiên gồm một số nguyên dương 
Dòng hai gồm 
 số nguyên 
, trong đó vị trị 
 có giá trị bằng 
 tức là vị trí 
 đang NULL
OUTPUT
Tiền thứ tự của cây
CONSTRAINTS
INPUT
Copy
4
1 4 -1 5
OUTPUT
Copy
1 4 5
*/
#include <stdio.h>

void preOrder(int arr[], int n, int i){
    if(i >= n || arr[i] == -1) return;
    printf("%d ", arr[i]);
    preOrder(arr, n, 2*i + 1);
    preOrder(arr, n, 2*i + 2);
}

int main(){
    int n;
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++) scanf("%d",&arr[i]);
    preOrder(arr,n,0);
    printf("\n");
    return 0;
}
