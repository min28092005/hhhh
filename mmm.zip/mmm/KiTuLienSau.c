/*Cho một kí tự in thường (a đến z), bạn hãy in ra kí tự đứng liền sau nó trong bảng chữ cái tiếng Anh. Lưu ý: kí tự liền sau của z là a.

Dữ liệu vào:
Một ký tự in thường.
Dữ liệu ra:
In ra một kí tự là kí tự liền sau nó.
Input:
Copy
d
Output:
Copy
e
*/
#include <stdio.h>

int main() {
    char c;
    scanf("%c", &c);
    printf("%c\n", (c == 'z') ? 'a' : c + 1);
    return 0;
}
