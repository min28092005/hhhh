/*Cho một cây nhị phân đang được lưu ở mảng một chiều (bắt đầu từ 0) có 
 phần tử Hãy in ra giá trị của node khi duyệt theo hậu tứ thự của cây đó

INPUT
Dòng đầu tiên gồm một số nguyên dương 
Dòng hai gồm 
 số nguyên 
, trong đó vị trị 
 có giá trị bằng -1 tức là vị trí 
 đang NULL
OUTPUT
Hậu thứ tự của cây
CONSTRAINTS
INPUT
Copy
4
1 4 -1 5
OUTPUT
Copy
5 4 1
*/
#include <stdio.h>

void postOrder(int arr[], int n, int index) {
    if (index >= n || arr[index] == -1) {
        return;
    }

    postOrder(arr, n, 2 * index + 1); 
    postOrder(arr, n, 2 * index + 2); 
    printf("%d ", arr[index]); 
}

int main() {
    int n;
    scanf("%d", &n);

    int arr[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    postOrder(arr, n, 0); 
    printf("\n");

    return 0;
}
