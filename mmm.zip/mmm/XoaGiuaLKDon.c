/*Cho một danh sách liên kết đơn không có phần tử nào. Mỗi một nút trong danh sách liên kết đơn có chứa một số nguyên dương

Hãy thêm vào đầu danh sách trên n phần tử số nguyên dương rồi xoá ở giữa danh sách đi m phần tử

INPUT
Dòng đầu tiên gồm hai số nguyên dương n, m
Dòng thứ hai là n số nguyên dương a
Dòng thứ ba chứa m số nguyên dương b, với mỗi số b chúng ta sẽ xoá đi phần tử liền sau phần tử có giá trị bằng b trong danh sách
OUTPUT
Gồm một dòng gồm số nguyên dương theo thứ tự khi in danh sách liên kết đơn còn lại từ đầu đến cuối
CONSTRAINTS
INPUT
Copy
4 2
8 4 1 9
8 1 
OUTPUT
Copy
9 1 8
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

Node* createNode(int val){
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = val;
    node->next = NULL;
    return node;
}

void addAtHead(Node** head, int val){
    Node* newNode = createNode(val);
    newNode->next = *head;
    *head = newNode;
}

void deleteAfterValue(Node** head, int val){
    Node* cur = *head;
    while(cur){
        if(cur->data == val && cur->next){
            Node* temp = cur->next;
            cur->next = cur->next->next;
            free(temp);
            return;
        }
        cur = cur->next;
    }
}

void printList(Node* head){
    Node* cur = head;
    while(cur){
        printf("%d", cur->data);
        if(cur->next) printf(" ");
        cur = cur->next;
    }
    printf("\n");
}

int main(){
    int n, m, val;
    Node* head = NULL;
    scanf("%d %d",&n,&m);

    for(int i=0;i<n;i++){
        scanf("%d",&val);
        addAtHead(&head,val);
    }

    for(int i=0;i<m;i++){
        scanf("%d",&val);
        deleteAfterValue(&head,val);
    }

    printList(head);
    return 0;
}
